<?php
// config/config.php
date_default_timezone_set('America/Lima');

return [
    'db_host'   => '127.0.0.1',
    'db_name'   => 'sistema_dental',
    'db_user'   => 'root',
    'db_pass'   => '',
    'db_charset'=> 'utf8mb4',
];
